CYBER SURAKSHA — ATTRACTIVE WEBSITE
Files:
- index.html
- style.css
- script.js

How to preview:
1. Extract this folder if downloaded as ZIP.
2. Keep all three files in the same folder.
3. Open index.html in a browser.
4. The site works without a server. Google Fonts require internet; fallback fonts are included.
5. Quiz runs locally and does not store answers or personal information.

For hosting:
- Upload these files to a static hosting service such as GitHub Pages, Netlify, or Vercel.
- Before public distribution, verify official helpline/reporting information.
