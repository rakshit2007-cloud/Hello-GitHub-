const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");
menuToggle.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.textContent = open ? "✕" : "☰";
});
navLinks.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  navLinks.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
  menuToggle.textContent = "☰";
}));

const languageToggle = document.getElementById("languageToggle");
let marathiMode = false;
languageToggle.addEventListener("click", () => {
  marathiMode = !marathiMode;
  languageToggle.textContent = marathiMode ? "English" : "मराठी";
  document.documentElement.lang = marathiMode ? "mr" : "en";
  document.body.classList.toggle("marathi-mode", marathiMode);
  // This site includes bilingual captions throughout; toggle scrolls attention to them.
  document.querySelectorAll(".mr, .hero-marathi").forEach(el => {
    el.classList.toggle("language-highlight", marathiMode);
  });
  if (marathiMode) {
    languageToggle.setAttribute("aria-label", "Switch back to English emphasis");
  } else {
    languageToggle.setAttribute("aria-label", "Highlight Marathi captions");
  }
});

document.getElementById("quizForm").addEventListener("submit", function(event) {
  event.preventDefault();
  const correct = {q1:"b", q2:"b", q3:"b"};
  let score = 0;
  const unanswered = [];
  for (const key of Object.keys(correct)) {
    const selected = document.querySelector('input[name="' + key + '"]:checked');
    if (!selected) unanswered.push(key);
    else if (selected.value === correct[key]) score++;
  }
  const result = document.getElementById("quizResult");
  result.classList.remove("error");
  if (unanswered.length) {
    result.textContent = "Please answer all 3 questions before checking your score. कृपया सर्व प्रश्नांची उत्तरे द्या.";
    result.classList.add("error");
  } else {
    const message = score === 3
      ? "Excellent! You scored 3/3. Keep practising safe habits. छान! सुरक्षित सवयी सुरू ठेवा."
      : "You scored " + score + "/3. Review the tips and try again. टिपा पुन्हा वाचा आणि प्रयत्न करा.";
    result.textContent = message;
  }
});
document.getElementById("quizForm").addEventListener("reset", () => {
  const result = document.getElementById("quizResult");
  result.textContent = "";
  result.classList.remove("error");
});
